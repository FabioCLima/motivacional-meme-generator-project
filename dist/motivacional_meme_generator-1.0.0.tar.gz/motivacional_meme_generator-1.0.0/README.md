# Intermediate Python Projects

Este repositório contém todos os projetos relacionados ao curso Intermediate Python da Udacity, organizados como submódulos Git para facilitar o gerenciamento e desenvolvimento independente de cada projeto.

## 📁 Estrutura do Repositório

### 🎭 Motivacional Meme Generator (Submódulo)

Um gerador de memes motivacionais que combina citações de diferentes formatos de arquivo com imagens, demonstrando conceitos avançados de Python como classes abstratas, padrões de design e uso do módulo subprocess.

**Localização:** `motivacional-meme-generator-project/`

### 🚀 Neo Project (Submódulo)

Projeto principal de análise de dados de Near-Earth Objects (NEOs).

**Localização:** `neo-project/`

## 🔧 Como Trabalhar com os Submódulos

### Clonando o Repositório com Submódulos

```bash
# Clonar o repositório com todos os submódulos
git clone --recursive https://github.com/FabioCLima/Intermediate-Python-projects.git

# Ou se já clonou, inicializar submódulos
git submodule update --init --recursive
```

### Trabalhando com o Motivacional Meme Generator

```bash
# Entrar no diretório do projeto
cd motivacional-meme-generator-project

# Ativar ambiente virtual (se existir)
source .venv/bin/activate  # Linux/Mac
# ou
.venv\Scripts\activate     # Windows

# Instalar dependências
pip install -r requirements.txt

# Executar testes
python test_implementation.py

# Executar o projeto principal
python main.py

# Executar servidor web
cd src && python app.py
```

### Trabalhando com o Neo Project

```bash
# Entrar no diretório do projeto
cd neo-project

# Ativar ambiente virtual
source .venv/bin/activate

# Executar testes
python -m pytest tests/

# Executar o projeto
python main.py
```

### Atualizando Submódulos

```bash
# Atualizar todos os submódulos para a versão mais recente
git submodule update --remote

# Atualizar um submódulo específico
git submodule update --remote motivacional-meme-generator-project
```

## 🎯 Funcionalidades (Motivacional Meme Generator)

- **Parsing de múltiplos formatos**: CSV, DOCX, PDF, TXT
- **Geração de memes**: Combina imagens com citações
- **Interface CLI**: Linha de comando para geração de memes
- **Interface Web**: Servidor Flask com formulário interativo
- **Função aleatória**: Seleciona citações e imagens aleatoriamente

## 🏗️ Arquitetura

### Padrões de Design Implementados

- **Strategy Pattern**: Ingestores específicos para cada tipo de arquivo
- **Facade Pattern**: Classe Ingestor principal que seleciona automaticamente
- **Abstract Factory**: Interface comum para todos os ingestores

### Estrutura do Projeto

```
motivacional-meme-generator-project/
├── src/
│   ├── app.py                     # Servidor Flask
│   ├── meme.py                    # Interface CLI
│   ├── MemeEngine.py              # Engine de manipulação de imagens
│   ├── QuoteEngine/               # Módulo de ingestão de citações
│   │   ├── ingestor_interface.py  # Interface abstrata
│   │   ├── ingestor.py            # Facade principal
│   │   ├── quote_model.py         # Modelo de dados
│   │   ├── csv_ingestor.py        # Estratégia para CSV
│   │   ├── docx_ingestor.py       # Estratégia para DOCX
│   │   ├── pdf_ingestor.py        # Estratégia para PDF
│   │   └── text_ingestor.py       # Estratégia para TXT
│   ├── _data/                     # Dados de exemplo
│   │   ├── DogQuotes/             # Citações em diferentes formatos
│   │   ├── SimpleLines/           # Citações simples
│   │   └── photos/                # Imagens para memes
│   └── templates/                 # Templates HTML
├── static/                        # Arquivos estáticos gerados
├── tests/                         # Testes unitários
└── requirements.txt               # Dependências
```

## 🚀 Instalação e Execução

### Pré-requisitos

- Python 3.8+
- Dependências Python (ver requirements.txt)
- Ferramentas do sistema para PDF (xpdf-utils ou mupdf-tools)

### Instalação

```bash
# Clonar o repositório
git clone <repository-url>
cd motivacional-meme-generator-project

# Criar ambiente virtual
python3 -m venv venv
source venv/bin/activate  # Linux/Mac
# ou
venv\Scripts\activate     # Windows

# Instalar dependências
pip install -r requirements.txt

# Instalar ferramentas PDF (Ubuntu/Debian)
sudo apt-get install -y xpdf-utils
```

### Execução

#### Interface Web (Recomendado)
```bash
cd src
python app.py
```
Acesse: http://127.0.0.1:5000/

#### Interface CLI
```bash
# Meme aleatório
python main.py

# Meme customizado
python src/meme.py --path ./src/_data/photos/dog/xander_1.jpg --body "Hello World" --author "Test Author"
```

#### Executar Testes
```bash
python test_implementation.py
```

## 📊 Resultados dos Testes

```
🚀 Running Implementation Tests
==================================================
🧪 Testing Quote Parsing...
✓ DogQuotesTXT.txt: 2 quotes
✓ DogQuotesCSV.csv: 2 quotes
✓ DogQuotesPDF.pdf: 3 quotes
✓ SimpleLines.txt: 5 quotes
✓ SimpleLines.csv: 5 quotes
✓ SimpleLines.pdf: 5 quotes
📊 Total quotes parsed: 22

🎨 Testing Meme Generation...
✓ Meme generated successfully

🔧 Testing Ingestor Interface...
✓ All interface tests passed

📊 Test Results: 3/3 tests passed
🎉 All tests passed! Implementation is working correctly.
```

## 🎯 Conformidade com Requisitos

### ✅ Requisitos Atendidos

1. **Interação com múltiplos tipos de arquivo**: CSV, DOCX, PDF, TXT
2. **Carregamento de citações**: 31 citações de 8 arquivos diferentes
3. **Manipulação de imagens**: MemeEngine com Pillow
4. **Interface CLI**: Script meme.py funcional
5. **Interface Web**: Servidor Flask em app.py
6. **Classes abstratas**: IngestorInterface
7. **Métodos de classe**: can_ingest e parse
8. **Padrão Strategy**: Ingestores específicos
9. **Padrão Facade**: Classe Ingestor principal
10. **PEP 8**: Código formatado corretamente
11. **Docstrings**: Documentação completa
12. **Tratamento de erros**: Try/catch blocks
13. **Subprocess**: Uso correto do módulo subprocess para PDFs
14. **Xpdf**: NÃO usa biblioteca PyPi pdftotext (conforme instruções)

### 🎨 Demonstração de Conceitos Python

- **Classes Abstratas**: `IngestorInterface` com métodos abstratos
- **Herança**: Todos os ingestores herdam da interface comum
- **Polimorfismo**: Mesmo método `parse()` para diferentes tipos
- **Módulo subprocess**: Para chamar ferramentas do sistema (pdftotext/mutool)
- **Type Hints**: Anotações de tipo em todos os métodos públicos
- **Tratamento de Exceções**: Try/catch robusto em todas as operações

## 🔧 Tecnologias Utilizadas

### Python Libraries
- **Pillow**: Manipulação de imagens
- **python-docx**: Processamento de documentos Word
- **Flask**: Framework web
- **requests**: Download de imagens

### System Tools
- **pdftotext** (xpdf-utils): Extração de texto de PDFs
- **mutool** (mupdf-tools): Alternativa para extração de PDFs

## 📝 Formato das Citações

O projeto espera citações no formato:
```
"Texto da citação" - Autor
```

### Exemplos Suportados:
- **TXT**: Linhas com citações separadas por "-"
- **CSV**: Colunas "body" e "author" (ou "quote" e "speaker")
- **DOCX**: Parágrafos com citações no formato padrão
- **PDF**: Linhas extraídas como texto com formato padrão

## 🎉 Funcionalidades Principais

### Interface Web
- **Página Principal**: Gera memes aleatórios automaticamente
- **Criador de Memes**: Formulário para memes customizados
- **Upload de Imagens**: Via URL direta de imagem
- **Texto Personalizado**: Citação e autor customizáveis

### Interface CLI
- **Meme Aleatório**: Seleciona imagem e citação aleatoriamente
- **Meme Customizado**: Parâmetros específicos via linha de comando
- **Flexibilidade**: Funciona com ou sem parâmetros

## 🏆 Conclusão

Este projeto demonstra uma implementação completa e robusta de um gerador de memes, seguindo todas as boas práticas de desenvolvimento Python e atendendo a todos os requisitos especificados. A arquitetura modular permite fácil extensão e manutenção, enquanto os padrões de design garantem código limpo e reutilizável.

**Projeto pronto para submissão e avaliação!** 🚀